/**
 * Kid's Box Student Finder - Frontend Controller
 * Fast, accessible, mobile-first lookup with zero score/rank leaks.
 */

(function () {
  'use strict';

  // Elements
  const studentInput = document.getElementById('student-name');
  const suggestionsBox = document.getElementById('suggestions');
  const classFilter = document.getElementById('class-filter');
  const findBtn = document.getElementById('find-btn');
  const resultArea = document.getElementById('result-area');
  const demoBanner = document.getElementById('demo-banner');

  // State
  let activeIndex = -1;
  let debounceTimer = null;
  let currentSuggestions = [];
  let isFetching = false;

  // Book covers mapping
  const BOOK_IMAGES = {
    "Kid's Box 1": "/img/kb1.jpg",
    "Kid's Box 2": "/img/kb2.jpg",
    "Kid's Box 3": "/img/kb3.jpg",
    "Kid's Box 4": "/img/kb4.jpg",
    "Kid's Box 5": "/img/kb5.jpg",
    "Kid's Box 6": "/img/kb6.jpg",
  };

  // Helper: Escape HTML
  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // Helper: Extract book image path
  function getBookCover(bookName) {
    if (BOOK_IMAGES[bookName]) {
      return BOOK_IMAGES[bookName];
    }
    const match = bookName && bookName.match(/(\d)/);
    if (match) {
      return `/img/kb${match[1]}.jpg`;
    }
    return '/img/kb1.jpg';
  }

  // 1. Initialize metadata
  async function init() {
    try {
      const res = await fetch('/api/meta');
      if (!res.ok) throw new Error('Meta failed');
      const meta = await res.json();

      // Demo banner visibility
      if (meta.demo && demoBanner) {
        demoBanner.hidden = false;
      } else if (demoBanner) {
        demoBanner.hidden = true;
      }

      // Populate classes
      if (Array.isArray(meta.classes) && classFilter) {
        // Clear except first
        classFilter.innerHTML = '<option value="">All classes</option>';
        meta.classes.forEach((c) => {
          const opt = document.createElement('option');
          opt.value = c;
          opt.textContent = c;
          classFilter.appendChild(opt);
        });
      }
    } catch (err) {
      console.warn('Could not load metadata:', err);
    }
  }

  // 2. Autocomplete suggestions
  function hideSuggestions() {
    suggestionsBox.hidden = true;
    suggestionsBox.innerHTML = '';
    studentInput.setAttribute('aria-expanded', 'false');
    studentInput.removeAttribute('aria-activedescendant');
    activeIndex = -1;
    currentSuggestions = [];
  }

  function renderSuggestions(items) {
    currentSuggestions = items;
    activeIndex = -1;
    if (!items || items.length === 0) {
      hideSuggestions();
      return;
    }

    suggestionsBox.innerHTML = items
      .map(
        (item, idx) => `
        <li
          id="sugg-${idx}"
          class="suggestion-item"
          role="option"
          aria-selected="false"
          data-id="${escapeHtml(item.id)}"
          data-name="${escapeHtml(item.name)}"
        >
          <svg class="suggestion-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
            <circle cx="12" cy="7" r="4"></circle>
          </svg>
          <span class="suggestion-name">${escapeHtml(item.name)}</span>
        </li>`
      )
      .join('');

    suggestionsBox.hidden = false;
    studentInput.setAttribute('aria-expanded', 'true');
  }

  function highlightSuggestion(index) {
    const listItems = suggestionsBox.querySelectorAll('.suggestion-item');
    listItems.forEach((li, idx) => {
      const isActive = idx === index;
      li.classList.toggle('active', isActive);
      li.setAttribute('aria-selected', isActive ? 'true' : 'false');
      if (isActive) {
        studentInput.setAttribute('aria-activedescendant', `sugg-${idx}`);
        li.scrollIntoView({ block: 'nearest' });
      }
    });
  }

  async function fetchSuggestions(query) {
    const q = query.trim();
    if (q.length < 1) {
      hideSuggestions();
      return;
    }

    try {
      const cls = classFilter.value ? encodeURIComponent(classFilter.value) : '';
      const url = `/api/suggest?q=${encodeURIComponent(q)}${cls ? `&class=${cls}` : ''}`;
      const res = await fetch(url);
      if (!res.ok) return;
      const data = await res.json();
      if (Array.isArray(data.suggestions)) {
        renderSuggestions(data.suggestions);
      }
    } catch (err) {
      console.warn('Suggest error:', err);
    }
  }

  // Handle select suggestion
  function selectSuggestion(item) {
    studentInput.value = item.name;
    hideSuggestions();
    loadStudentById(item.id);
  }

  // 3. Load by student ID
  async function loadStudentById(id) {
    setLoading(true);
    try {
      const res = await fetch(`/api/student?id=${encodeURIComponent(id)}`);
      if (!res.ok) {
        renderNotice('Student Not Found', 'Could not retrieve student details. Please try again.');
        return;
      }
      const student = await res.json();
      renderFound(student);
    } catch (err) {
      renderNotice('Connection Error', 'Please check your internet connection and try again.');
    } finally {
      setLoading(false);
    }
  }

  // 4. Primary Lookup
  async function performLookup() {
    const query = studentInput.value.trim();
    if (query.length < 3) {
      renderNotice(
        'Please enter a name',
        'Type at least 3 letters of your child\'s name to find their book.'
      );
      studentInput.focus();
      return;
    }

    hideSuggestions();
    setLoading(true);

    try {
      const cls = classFilter.value ? encodeURIComponent(classFilter.value) : '';
      const url = `/api/lookup?name=${encodeURIComponent(query)}${cls ? `&class=${cls}` : ''}`;
      const res = await fetch(url);
      if (!res.ok) {
        renderNotice('Search Error', 'Unable to look up student right now. Please try again.');
        return;
      }
      const data = await res.json();

      switch (data.status) {
        case 'found':
          renderFound(data.student);
          break;

        case 'ambiguous':
          renderAmbiguous(data.candidates);
          break;

        case 'not_found_in_class':
          renderNotFoundInClass(data.message, data.otherMatches);
          break;

        case 'not_found':
          renderNotFound(query);
          break;

        case 'invalid_input':
        default:
          renderNotice('Please refine your search', data.message || 'Please type at least 3 letters.');
          break;
      }
    } catch (err) {
      renderNotice('Connection Error', 'Please check your internet connection and try again.');
    } finally {
      setLoading(false);
    }
  }

  // Renderers
  function renderFound(student) {
    const coverUrl = getBookCover(student.book);
    const html = `
      <div class="result-card" role="region" aria-label="Student Book Assignment">
        <header class="result-header">
          <h2 class="student-name-display">${escapeHtml(student.name)}</h2>
          <div class="student-meta-badges">
            <span class="meta-badge meta-badge-class">Class: ${escapeHtml(student.className)}</span>
            <span class="meta-badge meta-badge-group">Groupe ${escapeHtml(student.group)}</span>
          </div>
        </header>

        <div class="book-showcase">
          <div class="book-callout">Required English Book</div>
          <div class="book-cover-wrap">
            <img
              src="${escapeHtml(coverUrl)}"
              alt="${escapeHtml(student.book)} cover"
              class="book-cover-img"
              loading="lazy"
              onerror="this.onerror=null; this.style.display='none';"
            />
          </div>
          <div class="book-name-prominent">${escapeHtml(student.book)}</div>
          <p class="book-instruction">Please purchase this Kid's Box level for your child.</p>
        </div>

        <button type="button" class="btn-reset" id="btn-search-again">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
            <polyline points="1 4 1 10 7 10"></polyline>
            <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"></path>
          </svg>
          Search Another Student
        </button>
      </div>
    `;
    resultArea.innerHTML = html;

    const againBtn = document.getElementById('btn-search-again');
    if (againBtn) {
      againBtn.addEventListener('click', resetSearch);
    }

    resultArea.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function renderAmbiguous(candidates) {
    const listHtml = (candidates || [])
      .map(
        (c) => `
        <li>
          <button
            type="button"
            class="ambiguous-option-btn"
            data-id="${escapeHtml(c.id)}"
          >
            <span class="ambiguous-name">${escapeHtml(c.name)}</span>
            <span class="ambiguous-class-badge">${escapeHtml(c.className)}</span>
          </button>
        </li>`
      )
      .join('');

    const html = `
      <div class="ambiguous-card" role="region" aria-label="Multiple Students Found">
        <div class="ambiguous-title">
          <span aria-hidden="true">⚠️</span>
          <span>Multiple Students Found</span>
        </div>
        <p class="ambiguous-desc">
          We found more than one student matching your search. Please tap your child's class below:
        </p>
        <ul class="ambiguous-list">
          ${listHtml}
        </ul>
        <button type="button" class="btn-reset" id="btn-search-again-ambig">
          Search Another Name
        </button>
      </div>
    `;
    resultArea.innerHTML = html;

    resultArea.querySelectorAll('.ambiguous-option-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        if (id) loadStudentById(id);
      });
    });

    const againBtn = document.getElementById('btn-search-again-ambig');
    if (againBtn) {
      againBtn.addEventListener('click', resetSearch);
    }

    resultArea.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function renderNotFoundInClass(message, otherMatches) {
    let othersHtml = '';
    if (Array.isArray(otherMatches) && otherMatches.length > 0) {
      othersHtml = `
        <div style="margin: 16px 0 12px 0; text-align: left;">
          <p style="font-size: 0.88rem; font-weight: 600; color: #475569; margin-bottom: 8px;">
            Found in another class:
          </p>
          <ul class="ambiguous-list">
            ${otherMatches
              .map(
                (m) => `
              <li>
                <button type="button" class="ambiguous-option-btn" data-id="${escapeHtml(m.id)}">
                  <span class="ambiguous-name">${escapeHtml(m.name)}</span>
                  <span class="ambiguous-class-badge">${escapeHtml(m.className)}</span>
                </button>
              </li>`
              )
              .join('')}
          </ul>
        </div>
      `;
    }

    const html = `
      <div class="notice-card" role="region" aria-label="Not in Selected Class">
        <div class="notice-icon" aria-hidden="true">🔍</div>
        <h3 class="notice-title">Class Mismatch</h3>
        <p class="notice-text">${escapeHtml(message || 'The student is not in the selected class.')}</p>
        ${othersHtml}
        <button type="button" class="btn-reset" id="btn-clear-filter">
          Clear Class Filter &amp; Search Again
        </button>
      </div>
    `;
    resultArea.innerHTML = html;

    resultArea.querySelectorAll('.ambiguous-option-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        if (id) loadStudentById(id);
      });
    });

    const clearBtn = document.getElementById('btn-clear-filter');
    if (clearBtn) {
      clearBtn.addEventListener('click', () => {
        classFilter.value = '';
        performLookup();
      });
    }

    resultArea.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function renderNotFound(name) {
    const html = `
      <div class="notice-card" role="region" aria-label="Student Not Found">
        <div class="notice-icon" aria-hidden="true">❓</div>
        <h3 class="notice-title">Student Not Found</h3>
        <p class="notice-text">
          We could not find <strong>"${escapeHtml(name)}"</strong> in the database.<br />
          Please double-check the spelling, or contact your child's English teacher or school administration for assistance.
        </p>
        <button type="button" class="btn-reset" id="btn-try-again">
          Try Another Name
        </button>
      </div>
    `;
    resultArea.innerHTML = html;

    const tryBtn = document.getElementById('btn-try-again');
    if (tryBtn) {
      tryBtn.addEventListener('click', resetSearch);
    }

    resultArea.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function renderNotice(title, desc) {
    const html = `
      <div class="notice-card" role="region" aria-label="${escapeHtml(title)}">
        <div class="notice-icon" aria-hidden="true">ℹ️</div>
        <h3 class="notice-title">${escapeHtml(title)}</h3>
        <p class="notice-text">${escapeHtml(desc)}</p>
      </div>
    `;
    resultArea.innerHTML = html;
  }

  function resetSearch() {
    studentInput.value = '';
    resultArea.innerHTML = '';
    hideSuggestions();
    studentInput.focus();
  }

  function setLoading(loading) {
    isFetching = loading;
    findBtn.disabled = loading;
    if (loading) {
      findBtn.innerHTML = '<span class="spinner" aria-hidden="true"></span>';
      resultArea.setAttribute('aria-busy', 'true');
    } else {
      findBtn.innerHTML = '<span class="btn-label">FIND MY BOOK</span>';
      resultArea.setAttribute('aria-busy', 'false');
    }
  }

  // Event Listeners
  studentInput.addEventListener('input', (e) => {
    const val = e.target.value;
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      fetchSuggestions(val);
    }, 180);
  });

  studentInput.addEventListener('keydown', (e) => {
    if (suggestionsBox.hidden || currentSuggestions.length === 0) {
      if (e.key === 'Enter') {
        e.preventDefault();
        performLookup();
      }
      return;
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      activeIndex = (activeIndex + 1) % currentSuggestions.length;
      highlightSuggestion(activeIndex);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      activeIndex = (activeIndex - 1 + currentSuggestions.length) % currentSuggestions.length;
      highlightSuggestion(activeIndex);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (activeIndex >= 0 && activeIndex < currentSuggestions.length) {
        selectSuggestion(currentSuggestions[activeIndex]);
      } else {
        performLookup();
      }
    } else if (e.key === 'Escape') {
      hideSuggestions();
    }
  });

  // Suggestion click delegation
  suggestionsBox.addEventListener('click', (e) => {
    const itemEl = e.target.closest('.suggestion-item');
    if (!itemEl) return;
    const id = itemEl.getAttribute('data-id');
    const name = itemEl.getAttribute('data-name');
    if (id && name) {
      selectSuggestion({ id, name });
    }
  });

  // Click outside closes dropdown
  document.addEventListener('click', (e) => {
    if (!studentInput.contains(e.target) && !suggestionsBox.contains(e.target)) {
      hideSuggestions();
    }
  });

  // Class filter change
  classFilter.addEventListener('change', () => {
    if (studentInput.value.trim().length >= 3) {
      performLookup();
    }
  });

  // Primary button click
  findBtn.addEventListener('click', () => {
    performLookup();
  });

  // Start app
  init();
})();
